module.exports = {
  semi: true,
  singleQuote: true,
  bracketSpacing: false,
  singleQuote: true,
  trailingComma: 'es5',
  arrowParens: 'avoid',
};
